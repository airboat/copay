export type LocalStorageData = ReadonlyArray<{
  key: string;
  value: string;
}>;
