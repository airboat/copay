export interface GiftCardNewData {
  status: 'expired';
}
